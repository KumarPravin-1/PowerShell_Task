﻿write-host("Pravin Kumar Verma")
$serverlistpath = "C:\Users\Administrator.DEMO\Desktop\Demo\serverlist.txt" #check your path 
 #add these all in server list file and paste path here#wfa#dc1#localhost 
$serverlist = Get-Content -Path $serverlistpath -ErrorAction SilentlyContinue  
foreach($server in $serverlist) 
{ $Test_connection = Test-Connection -ComputerName $server -Quiet -ErrorAction SilentlyContinue 
 #here all server will come one by one just paste your code here and replace your server with  
write-host $server
 Enter-PSSession $server 
pwd
New-Item -path \$server\C$\windows\temp\test\pkv -ItemType 'Directory'
Test-Path -path \$server\C$\windows\temp\test\pkv
new-item -Path \$server\C$\windows\temp\test\pkv\pkv.txt -ItemType 'file'  
Test-Path \$server\C$\windows\temp\test\pkv\pkv.txt  
 Exit-PSSession  }