﻿write-host("Pravin Kumar Verma")
Import-Module ActiveDirectory
New-ADUser -Name Pravin