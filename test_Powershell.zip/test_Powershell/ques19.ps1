﻿ write-host("Pravin Kumar Verma")
 Get-WmiObject -Class Win32_BIOS -ComputerName localhost, dc1, wfa, AIQUM | Out-GridView 
