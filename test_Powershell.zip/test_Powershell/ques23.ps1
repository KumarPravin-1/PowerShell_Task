﻿ Write-Host("Pravin Kumar Verma")
 Get-Help Format-Table -Detailed
 Get-Help Format-Table -Full 
