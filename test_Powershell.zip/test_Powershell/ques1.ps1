﻿write-host("Pravin Kumar Verma")
New-Item -path 'C:\Users\user\OneDrive\Pravin\OneDrive\Desktop\q1.csv' -ItemType 'File'
get-service | select -property status,Name,RequiredServices,DependentServices | Out-File 'C:\Users\user\OneDrive\Pravin\OneDrive\Desktop\q1.csv' -append -force