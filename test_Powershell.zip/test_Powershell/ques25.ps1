﻿ write-host("Pravin Kumar Verma")
 get-eventlog -LogName Security -InstanceId 4672 -ComputerName localhost, dc1, AIQUM 
