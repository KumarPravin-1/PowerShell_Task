﻿ write-host("Pravin Kumar Verma")
 $P = New-PSSession -ComputerName @("AIQUM","localhost","dc1","win1")
 ForEach ($Computer in $P){          
    [System.Net.DNS]::GetHostByName('').HostName                 
 } 
