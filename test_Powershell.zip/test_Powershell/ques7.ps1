﻿ Write-Host("Pravin Kumar Verma")
 get-process -Name c* -ComputerName dc1 | Format-Table -Property ID, Processname, Machinename  
