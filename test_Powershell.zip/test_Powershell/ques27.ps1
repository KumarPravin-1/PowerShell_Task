﻿ Write-Host("Pravin Kumar Verma")
 $From = "pkpallavi@outlook.com"
 $To = "mohit.my844@outlook.com"
 $Cc = "pravin.paro1998@gmail.com" 
 $Subject = "Task Completed"  
 $Body = "Test mail for test" 
 $SMTPServer = "smtp.outlook.com"  
 $SMTPPort = "587" 
 $attachment = 'C:\Users\user\OneDrive\Pravin\OneDrive\Desktop\ques27.html' #check you path with this file
 Send-MailMessage -From $From -to $To -Cc $Cc -Subject $Subject -Body $Body -BodyAsHtml  -SmtpServer $SMTPServer -Port $SMTPPort -Attachments $attachment -UseSsl -Credential $credentials