﻿write-host("Pravin Kumar Verma")
$serverlistpath = "C:\Users\Administrator.DEMO\Desktop\Demo\serverlist.txt" 
$serverlist = Get-Content -Path $serverlistpath -ErrorAction SilentlyContinue
foreach($server in $serverlist) {$Test_connection = Test-Connection -ComputerName $server -Quiet -ErrorAction
SilentlyContinue write-host connection set $server  Enter-PSSession jumphost write-host login to jumphost 
if((Test-Path -Path '\jumphost\C$\windows\temp\jump_file.txt' )-eq "True") 
{Copy-Item -Path '\jumphost\C$\windows\temp\jump_file.txt'  -Destination \$server\c$\windows\temp\Copied_from_jmpHost.txt -Recurse -Force write-host file copied 1st run Exit-PSSession write-host exited from jumphost write-host -----------} 
Else{Set-Content '\jumphost\C$\windows\temp\jump_file.txt' 'Hello I am From Jumphost' write-host file created Copy-Item -Path '\jumphost\C$\windows\temp\jump_file.txt'  -Destination \$server\c$\windows\temp\Copied_from_jmpHost.txt -Recurse -Force write-host file copied 2nd run Exit-PSSession write-host exited from jumphost write-host ---------}}