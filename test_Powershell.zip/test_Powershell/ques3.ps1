﻿write-host("Pravin Kumar Verma")
Get-WmiObject win32_networkadapterconfiguration | select description,  macaddress, ipaddress